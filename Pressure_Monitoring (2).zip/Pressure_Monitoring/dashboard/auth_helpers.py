"""
Helpers for clinician access to patient data (all or selected groups).
"""
from django.db.models import Q

from .models import UserProfile, ClinicianPatientAccess, PatientGroup


def get_profile(user):
    """Return UserProfile for user or None."""
    if not user or not user.is_authenticated:
        return None
    try:
        return user.profile
    except UserProfile.DoesNotExist:
        return None


def get_patients_accessible_by_clinician(clinician):
    """
    Return queryset of User (patient) IDs that this clinician can view.
    Includes: patients in groups the clinician has access to, or explicitly granted patients.
    """
    from django.contrib.auth import get_user_model
    User = get_user_model()

    # Groups this clinician has access to
    group_ids = ClinicianPatientAccess.objects.filter(
        clinician=clinician,
        group__isnull=False,
    ).values_list("group_id", flat=True)

    # Patient IDs from those groups
    from .models import PatientGroup
    patient_ids_from_groups = set(
        PatientGroup.objects.filter(id__in=group_ids).values_list("patients", flat=True)
    )
    patient_ids_from_groups.discard(None)

    # Individually granted patients
    individual_ids = set(
        ClinicianPatientAccess.objects.filter(
            clinician=clinician,
            patient__isnull=False,
        ).values_list("patient_id", flat=True)
    )
    individual_ids.discard(None)

    all_ids = patient_ids_from_groups | individual_ids
    return User.objects.filter(id__in=all_ids, profile__role=UserProfile.Role.PATIENT)


def can_clinician_view_patient(clinician, patient):
    """Check if clinician is allowed to view this patient's data."""
    if not clinician or not patient:
        return False
    # Same user
    if clinician.id == patient.id:
        return True
    # Explicit patient access
    if ClinicianPatientAccess.objects.filter(
        clinician=clinician,
        patient=patient,
    ).exists():
        return True
    # Via group
    group_ids = ClinicianPatientAccess.objects.filter(
        clinician=clinician,
        group__isnull=False,
    ).values_list("group_id", flat=True)
    return PatientGroup.objects.filter(
        id__in=group_ids,
        patients=patient,
    ).exists()
