"""
Role-based access decorators. Ensures secure authentication and authorization.
"""
from functools import wraps
from django.shortcuts import redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages

from .models import UserProfile


def role_required(*allowed_roles):
    """Require user to be logged in and have one of the given roles."""
    def decorator(view_func):
        @wraps(view_func)
        def _wrapped_view(request, *args, **kwargs):
            if not request.user.is_authenticated:
                return redirect("dashboard:login")
            try:
                profile = request.user.profile
            except UserProfile.DoesNotExist:
                messages.error(request, "User profile not found. Please contact admin.")
                return redirect("dashboard:login")
            if profile.role not in allowed_roles:
                messages.error(request, "You do not have permission to view this page.")
                return redirect("dashboard:home")
            return view_func(request, *args, **kwargs)
        return _wrapped_view
    return decorator


def admin_required(view_func):
    """Require admin role."""
    return login_required(role_required(UserProfile.Role.ADMIN)(view_func))


def clinician_required(view_func):
    """Require clinician role."""
    return login_required(role_required(UserProfile.Role.CLINICIAN)(view_func))


def patient_required(view_func):
    """Require patient role."""
    return login_required(role_required(UserProfile.Role.PATIENT)(view_func))
