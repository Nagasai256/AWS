"""
Pressure map analysis: CSV parsing, Peak Pressure Index, Contact Area %,
high-pressure region detection and alerts.
"""
import csv
import io
from datetime import datetime
from collections import deque

# Default thresholds (configurable)
LOWER_THRESHOLD = 5.0   # pixels below this are not counted as "contact"
HIGH_PRESSURE_THRESHOLD = 80.0   # above this we flag for alert
MIN_PIXELS_FOR_PPI = 10   # exclude regions smaller than this for PPI


def parse_pressure_csv(content_or_path, has_header=True):
    """
    Parse CSV into list of frames. Each frame is (timestamp, grid).
    content_or_path: file-like (with .read()), bytes, str (CSV content), or path to a file.
    Returns: list of (datetime, grid) where grid is list[list[float]].
    """
    if hasattr(content_or_path, "read"):
        text = content_or_path.read()
    elif isinstance(content_or_path, bytes):
        text = content_or_path.decode("utf-8-sig")
    elif isinstance(content_or_path, str):
        # Treat as file path only if it looks like a path (no newline, no CSV-style comma start)
        if "\n" in content_or_path or "\r" in content_or_path or (len(content_or_path) > 2 and content_or_path.strip()[0].isdigit()):
            text = content_or_path
        else:
            with open(content_or_path, "r", encoding="utf-8-sig") as f:
                text = f.read()
    else:
        text = content_or_path

    if isinstance(text, bytes):
        text = text.decode("utf-8-sig")
    reader = csv.reader(io.StringIO(text.strip()))
    rows = list(reader)
    if not rows:
        return []

    # Detect format: if first cell of first row is number, no per-row timestamp
    result = []
    first_row = rows[0]
    if has_header and not _is_numeric(first_row[0]):
        rows = rows[1:]
        if not rows:
            return []

    # Single grid: all rows are numeric (or first column timestamp)
    try:
        float(first_row[0])
        numeric_first = True
    except (ValueError, TypeError):
        numeric_first = False

    if numeric_first or (len(first_row) > 1 and _is_numeric(first_row[1])):
        # One grid per file or we need to split by blank rows / timestamp column
        grid = _rows_to_grid(rows, has_timestamp_column=not _is_numeric(rows[0][0]))
        if grid:
            result.append((datetime.utcnow(), grid))
        return result

    # Assume each row is a full grid row
    grid = _rows_to_grid(rows, has_timestamp_column=False)
    if grid:
        result.append((datetime.utcnow(), grid))
    return result


def _is_numeric(s):
    try:
        float(s)
        return True
    except (ValueError, TypeError):
        return False


def _rows_to_grid(rows, has_timestamp_column=False):
    """Convert list of CSV rows to grid of floats. Optionally skip first column (timestamp)."""
    grid = []
    start = 1 if has_timestamp_column else 0
    for row in rows:
        if not row:
            continue
        try:
            values = [float(row[i]) for i in range(start, len(row)) if i < len(row)]
            if values:
                grid.append(values)
        except (ValueError, TypeError):
            continue
    return grid if grid else None


def get_connected_components(grid, threshold):
    """
    Return list of sets of (r, c) coordinates where value >= threshold, grouped by connectivity (4-neighbour).
    """
    if not grid:
        return []
    rows, cols = len(grid), len(grid[0]) if grid else 0
    visited = set()
    components = []

    def neighbours(r, c):
        for dr, dc in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
            nr, nc = r + dr, c + dc
            if 0 <= nr < rows and 0 <= nc < cols:
                yield nr, nc

    for r in range(rows):
        for c in range(cols):
            if (r, c) in visited or grid[r][c] < threshold:
                continue
            comp = set()
            stack = [(r, c)]
            while stack:
                rr, cc = stack.pop()
                if (rr, cc) in visited or grid[rr][cc] < threshold:
                    continue
                visited.add((rr, cc))
                comp.add((rr, cc))
                for nr, nc in neighbours(rr, cc):
                    if (nr, nc) not in visited and grid[nr][nc] >= threshold:
                        stack.append((nr, nc))
            if comp:
                components.append(comp)
    return components


def compute_peak_pressure_index(grid, lower_threshold=LOWER_THRESHOLD, min_pixels=MIN_PIXELS_FOR_PPI):
    """
    Highest recorded pressure in the frame, excluding any areas of less than 10 pixels.
    """
    if not grid:
        return None
    components = get_connected_components(grid, lower_threshold)
    valid_cells = set()
    for comp in components:
        if len(comp) >= min_pixels:
            valid_cells.update(comp)
    if not valid_cells:
        return None
    max_val = max(grid[r][c] for r, c in valid_cells)
    return round(max_val, 2)


def compute_contact_area_pct(grid, lower_threshold=LOWER_THRESHOLD):
    """Percentage of pixels above lower threshold (how much of sensor mat is covered)."""
    if not grid:
        return None
    rows, cols = len(grid), len(grid[0])
    total = rows * cols
    above = sum(1 for row in grid for v in row if v >= lower_threshold)
    return round(100.0 * above / total, 2) if total else None


def compute_mean_pressure(grid, lower_threshold=LOWER_THRESHOLD):
    """Mean pressure over pixels above threshold."""
    if not grid:
        return None
    vals = [v for row in grid for v in row if v >= lower_threshold]
    return round(sum(vals) / len(vals), 2) if vals else None


def detect_high_pressure_regions(grid, threshold=HIGH_PRESSURE_THRESHOLD, min_pixels=5):
    """Return list of components (each a set of (r,c)) that are high-pressure regions."""
    return [c for c in get_connected_components(grid, threshold) if len(c) >= min_pixels]


def should_raise_alert(grid, high_pressure_threshold=HIGH_PRESSURE_THRESHOLD):
    """Determine if we should create an alert and severity."""
    regions = detect_high_pressure_regions(grid, high_pressure_threshold)
    if not regions:
        return False, None
    max_size = max(len(r) for r in regions)
    if max_size >= 50:
        return True, "high"
    if max_size >= 20:
        return True, "medium"
    return True, "low"


def compute_frame_metrics(grid, lower_threshold=LOWER_THRESHOLD, high_threshold=HIGH_PRESSURE_THRESHOLD):
    """
    Return dict: peak_pressure_index, contact_area_pct, mean_pressure, max_pressure_raw,
    high_pressure_region_count, and whether to alert with severity.
    """
    if not grid:
        return {}
    max_raw = max(v for row in grid for v in row)
    high_regions = detect_high_pressure_regions(grid, high_threshold)
    alert, severity = should_raise_alert(grid, high_threshold)
    return {
        "peak_pressure_index": compute_peak_pressure_index(grid, lower_threshold),
        "contact_area_pct": compute_contact_area_pct(grid, lower_threshold),
        "mean_pressure": compute_mean_pressure(grid, lower_threshold),
        "max_pressure_raw": round(max_raw, 2),
        "high_pressure_region_count": len(high_regions),
        "alert": alert,
        "alert_severity": severity,
    }
