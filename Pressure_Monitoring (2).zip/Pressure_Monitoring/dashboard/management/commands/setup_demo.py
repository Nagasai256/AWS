"""
Create demo users and optional sample data.
Usage: python manage.py setup_demo
"""
from django.core.management.base import BaseCommand
from django.contrib.auth import get_user_model
from django.utils import timezone

from dashboard.models import UserProfile, PatientGroup, ClinicianPatientAccess

User = get_user_model()


class Command(BaseCommand):
    help = "Create demo admin, clinician, and patient users; optional groups."

    def handle(self, *args, **options):
        def get_or_create(username, password, role):
            user, created = User.objects.get_or_create(
                username=username,
                defaults={"is_staff": role == "admin", "is_superuser": role == "admin"},
            )
            if created:
                user.set_password(password)
                user.save()
                UserProfile.objects.get_or_create(user=user, defaults={"role": role})
            else:
                profile, _ = UserProfile.objects.get_or_create(user=user, defaults={"role": role})
                if profile.role != role:
                    profile.role = role
                    profile.save(update_fields=["role"])
            return user

        admin = get_or_create("admin", "admin123", UserProfile.Role.ADMIN)
        clin = get_or_create("clinician1", "clinician123", UserProfile.Role.CLINICIAN)
        for i in range(1, 6):
            get_or_create(f"patient{i}", "patient123", UserProfile.Role.PATIENT)

        # Create a group and assign patients 1-3 to it; grant clinician access
        group, _ = PatientGroup.objects.get_or_create(name="Group A", defaults={"description": "Demo group"})
        for i in range(1, 4):
            u = User.objects.get(username=f"patient{i}")
            group.patients.add(u)
        ClinicianPatientAccess.objects.get_or_create(clinician=clin, group=group)

        self.stdout.write(self.style.SUCCESS(
            "Demo users: admin/admin123, clinician1/clinician123, patient1..patient5/patient123. Group A has patient1-3; clinician1 has access to Group A."
        ))
