"""
Management command to import pressure map CSV for a user.
Usage: python manage.py import_pressure_csv <username> <path_to.csv> [session_name]
"""
from django.core.management.base import BaseCommand
from django.contrib.auth import get_user_model
from django.utils import timezone

from dashboard.models import PressureMapSession, PressureFrame, PressureMetric, PressureAlert, UserProfile
from dashboard.services.pressure_analysis import parse_pressure_csv, compute_frame_metrics

User = get_user_model()


class Command(BaseCommand):
    help = "Import pressure map CSV for a patient user."

    def add_arguments(self, parser):
        parser.add_argument("username", type=str)
        parser.add_argument("csv_path", type=str)
        parser.add_argument("session_name", type=str, nargs="?", default="")

    def handle(self, *args, **options):
        username = options["username"]
        csv_path = options["csv_path"]
        session_name = options["session_name"] or csv_path
        user = User.objects.filter(username=username).first()
        if not user:
            self.stderr.write(self.style.ERROR(f"User '{username}' not found."))
            return
        try:
            with open(csv_path, "r", encoding="utf-8-sig") as f:
                content = f.read()
        except Exception as e:
            self.stderr.write(self.style.ERROR(str(e)))
            return
        frames_data = parse_pressure_csv(content)
        if not frames_data:
            self.stderr.write(self.style.ERROR("No valid pressure data in CSV."))
            return
        started = timezone.now()
        session = PressureMapSession.objects.create(patient=user, name=session_name, started_at=started)
        count = 0
        for ts, grid in frames_data:
            frame = PressureFrame.objects.create(
                session=session,
                timestamp=ts,
                data_json=grid,
                rows=len(grid),
                cols=len(grid[0]) if grid else 0,
            )
            metrics_dict = compute_frame_metrics(grid)
            PressureMetric.objects.create(
                frame=frame,
                peak_pressure_index=metrics_dict.get("peak_pressure_index"),
                contact_area_pct=metrics_dict.get("contact_area_pct"),
                mean_pressure=metrics_dict.get("mean_pressure"),
                max_pressure_raw=metrics_dict.get("max_pressure_raw"),
                high_pressure_region_count=metrics_dict.get("high_pressure_region_count", 0),
                extra_metrics_json=metrics_dict,
            )
            if metrics_dict.get("alert"):
                PressureAlert.objects.create(
                    frame=frame,
                    severity=metrics_dict.get("alert_severity", "medium"),
                    message="High pressure region detected",
                    flagged_for_review=True,
                )
            count += 1
        session.ended_at = timezone.now()
        session.save(update_fields=["ended_at"])
        self.stdout.write(self.style.SUCCESS(f"Imported {count} frame(s) into session {session.id} for {username}."))
