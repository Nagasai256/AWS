# Pressure Monitoring System

Django-based pressure map monitoring with three user roles (patient, clinician, admin), time-ordered data, key metrics (Peak Pressure Index, Contact Area %), alerts, visualisations, reports, and user/clinician feedback.

## Tech stack

- **Backend:** Python, Django 6.x
- **Database:** SQLite (default); MySQL supported via settings
- **Frontend:** HTML, CSS, JavaScript, Bootstrap 5, Chart.js
- **Security:** Django auth, CSRF, parameterised ORM (no raw SQL), role-based access

## Setup

1. **Create virtual environment and install dependencies**
   ```bash
   python -m venv venv
   venv\Scripts\activate   # Windows
   pip install -r requirements.txt
   ```

2. **Run migrations**
   ```bash
   python manage.py migrate
   ```

3. **Create demo users (admin, clinician, 5 patients, 1 group)**
   ```bash
   python manage.py setup_demo
   ```
   Logins: `admin` / `admin123`, `clinician1` / `clinician123`, `patient1`–`patient5` / `patient123`.

4. **Optional: Import sample CSV**
   ```bash
   python manage.py import_pressure_csv patient1 sample_data\sample_pressure_1.csv "Day 1"
   ```

5. **Run server**
   ```bash
   python manage.py runserver
   ```
   Open http://127.0.0.1:8000/ and log in.

## Using MySQL

In `pressure_monitoring/settings.py`, comment out the default SQLite `DATABASES` and uncomment the MySQL block; set `NAME`, `USER`, `PASSWORD`, `HOST`, `PORT`. Install `mysqlclient` and run `migrate`.

## Features

- **Database:** Time-ordered pressure frames per user (sessions → frames → metrics, alerts, comments).
- **Roles:** Patient (own data), Clinician (all/selected groups via Admin), Admin (create users, manage groups).
- **Analysis:** Peak Pressure Index (excluding regions &lt; 10 pixels), Contact Area %, high-pressure alerts flagged for clinician review.
- **Visualisation:** Heat map per frame; line charts for PPI and Contact Area % over time (last 1h, 6h, 24h, 7d, all).
- **Reports:** Session summary and comparison to previous session (day-to-day).
- **Feedback:** Patient comments linked to frame timestamp; clinician replies in-thread.
- **Plain-English:** “Explain” button for a frame returns a short explanation of the metrics.

## Version control

Use Git (e.g. GitHub) for the project; ensure `.gitignore` includes `db.sqlite3`, `venv/`, `__pycache__/`, `*.pyc`, `staticfiles/`, and env files with secrets.
